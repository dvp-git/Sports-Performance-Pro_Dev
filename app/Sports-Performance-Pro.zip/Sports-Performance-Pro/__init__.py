# app/__init__.py
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config


# Import routes and models after creating app and 

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)

from app import routes, models  