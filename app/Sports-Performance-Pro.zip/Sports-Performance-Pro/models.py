# app/models.py
from app import db


#date requiured
# Coach : Institution

class Coaches(db.Model):
    coach_id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    # address = db.Column(db.String(255))
    email = db.Column(db.String(255), unique=True, nullable=False)
    # gender = db.Column(db.String(1), db.CheckConstraint("gender IN ('M', 'F')"),nullable=False)
    password = db.Column(db.String(255),unique=True, nullable=False)
    phone = db.Column(db.String(255), unique=True)
    sports = db.Column(db.String(255))
    institute = db.Column(db.String(255))

class Athletes(db.Model):
    athlete_id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    # Discuss gender Male , Female, Other
    gender = db.Column(db.String(10), db.CheckConstraint("gender IN ('male', 'female', 'other')"),nullable=False)
    password = db.Column(db.String(255),unique=True, nullable=False)
    phone = db.Column(db.String(255), unique=True)
    sports = db.Column(db.String(255))
    institute = db.Column(db.String(255))




class Teams(db.Model):
    team_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    sport = db.Column(db.String(255), nullable=False)
    institute = db.Column(db.String(255))
    coach_id = db.Column(db.Integer, db.ForeignKey('coaches.coach_id'))
   

class TeamMemberships(db.Model):
    __tablename__ = 'team_memberships'
    membership_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    athlete_id = db.Column(db.Integer, db.ForeignKey('athletes.athlete_id'))
    team_id = db.Column(db.Integer, db.ForeignKey('teams.team_id'))

class Workouts(db.Model):
    workout_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    coach_id = db.Column(db.Integer, db.ForeignKey('coaches.coach_id'), nullable=False)
    # Define a relationship with Coach (assuming you have a Coach model)
    coach = db.relationship('Coaches', backref=db.backref('workouts', lazy=True))
    
class Blocks(db.Model):
    block_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    workout_id = db.Column(db.Integer, db.ForeignKey('workouts.workout_id'), nullable=False)
    workout = db.relationship('Workouts', backref=db.backref('blocks', lazy=True))


class Exercises(db.Model):
    exercise_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    block_id = db.Column(db.Integer, db.ForeignKey('blocks.block_id'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    loads = db.Column(db.String(255))
    reps = db.Column(db.Integer)
    sets = db.Column(db.Integer)


