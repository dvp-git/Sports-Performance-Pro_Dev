from flask import Flask, request
import mysql.connector
from urllib.parse import quote_plus

class Config:
    SECRET_KEY = 'your_secret_key_here'
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:%s@localhost/sports-performance-pro-db' % quote_plus("macbookPro@2022")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
